#!/bin/sh

git archive --format=tar.gz --prefix=keystone-latest/ HEAD > keystone-latest.tgz
