let keystone_header_loc = "\"/usr/local/include/keystone/keystone.h\""
