// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [mipsConstants.cs]
namespace Keystone
{
	public enum MipsError : short
	{
		KS_ERR_ASM_MIPS_INVALIDOPERAND = 512,
		KS_ERR_ASM_MIPS_MISSINGFEATURE = 513,
		KS_ERR_ASM_MIPS_MNEMONICFAIL = 514,
	}
}