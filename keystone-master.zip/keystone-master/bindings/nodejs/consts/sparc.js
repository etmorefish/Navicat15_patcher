// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [sparc_const.js]
module.exports.ERR_ASM_SPARC_INVALIDOPERAND = 512
module.exports.ERR_ASM_SPARC_MISSINGFEATURE = 513
module.exports.ERR_ASM_SPARC_MNEMONICFAIL = 514
