// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [x86_const.js]
module.exports.ERR_ASM_X86_INVALIDOPERAND = 512
module.exports.ERR_ASM_X86_MISSINGFEATURE = 513
module.exports.ERR_ASM_X86_MNEMONICFAIL = 514
