// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [ppc_const.js]
module.exports.ERR_ASM_PPC_INVALIDOPERAND = 512
module.exports.ERR_ASM_PPC_MISSINGFEATURE = 513
module.exports.ERR_ASM_PPC_MNEMONICFAIL = 514
